﻿namespace LightSnake
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.檔案ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LoadAudioMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LoadFile_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Export_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.編輯ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CopyKeyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PasteKeyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CutKeyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DeleteKeyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_color = new System.Windows.Forms.Button();
            this.lab_color = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txt_p4 = new System.Windows.Forms.TextBox();
            this.lab_p4 = new System.Windows.Forms.Label();
            this.txt_p3 = new System.Windows.Forms.TextBox();
            this.lab_p3 = new System.Windows.Forms.Label();
            this.txt_p2 = new System.Windows.Forms.TextBox();
            this.lab_p2 = new System.Windows.Forms.Label();
            this.txt_p1 = new System.Windows.Forms.TextBox();
            this.lab_p1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox_Mode = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lab_YV_p2 = new System.Windows.Forms.Label();
            this.txt_YV_p2 = new System.Windows.Forms.TextBox();
            this.lab_YV_p1 = new System.Windows.Forms.Label();
            this.txt_YV_p1 = new System.Windows.Forms.TextBox();
            this.lab_YV_Lower = new System.Windows.Forms.Label();
            this.txt_YV_Lower = new System.Windows.Forms.TextBox();
            this.lab_YV_Range = new System.Windows.Forms.Label();
            this.comboBox_YV_func = new System.Windows.Forms.ComboBox();
            this.txt_YV_Range = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.lab_YS_p2 = new System.Windows.Forms.Label();
            this.txt_YS_p2 = new System.Windows.Forms.TextBox();
            this.lab_YS_p1 = new System.Windows.Forms.Label();
            this.txt_YS_p1 = new System.Windows.Forms.TextBox();
            this.lab_YS_Lower = new System.Windows.Forms.Label();
            this.txt_YS_Lower = new System.Windows.Forms.TextBox();
            this.lab_YS_Range = new System.Windows.Forms.Label();
            this.comboBox_YS_func = new System.Windows.Forms.ComboBox();
            this.txt_YS_Range = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.lab_YH_p2 = new System.Windows.Forms.Label();
            this.txt_YH_p2 = new System.Windows.Forms.TextBox();
            this.lab_YH_p1 = new System.Windows.Forms.Label();
            this.txt_YH_p1 = new System.Windows.Forms.TextBox();
            this.lab_YH_Lower = new System.Windows.Forms.Label();
            this.txt_YH_Lower = new System.Windows.Forms.TextBox();
            this.lab_YH_Range = new System.Windows.Forms.Label();
            this.comboBox_YH_func = new System.Windows.Forms.ComboBox();
            this.txt_YH_Range = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.lab_XV_p2 = new System.Windows.Forms.Label();
            this.txt_XV_p2 = new System.Windows.Forms.TextBox();
            this.lab_XV_p1 = new System.Windows.Forms.Label();
            this.txt_XV_p1 = new System.Windows.Forms.TextBox();
            this.lab_XV_Lower = new System.Windows.Forms.Label();
            this.txt_XV_Lower = new System.Windows.Forms.TextBox();
            this.lab_XV_Range = new System.Windows.Forms.Label();
            this.comboBox_XV_func = new System.Windows.Forms.ComboBox();
            this.txt_XV_Range = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lab_XS_p2 = new System.Windows.Forms.Label();
            this.txt_XS_p2 = new System.Windows.Forms.TextBox();
            this.lab_XS_p1 = new System.Windows.Forms.Label();
            this.txt_XS_p1 = new System.Windows.Forms.TextBox();
            this.lab_XS_Lower = new System.Windows.Forms.Label();
            this.txt_XS_Lower = new System.Windows.Forms.TextBox();
            this.lab_XS_Range = new System.Windows.Forms.Label();
            this.comboBox_XS_func = new System.Windows.Forms.ComboBox();
            this.txt_XS_Range = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lab_XH_p2 = new System.Windows.Forms.Label();
            this.txt_XH_p2 = new System.Windows.Forms.TextBox();
            this.lab_XH_p1 = new System.Windows.Forms.Label();
            this.txt_XH_p1 = new System.Windows.Forms.TextBox();
            this.lab_XH_Lower = new System.Windows.Forms.Label();
            this.txt_XH_Lower = new System.Windows.Forms.TextBox();
            this.lab_XH_Range = new System.Windows.Forms.Label();
            this.comboBox_XH_func = new System.Windows.Forms.ComboBox();
            this.txt_XH_Range = new System.Windows.Forms.TextBox();
            this.lab_XH = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox_effect = new System.Windows.Forms.ListBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelWaveform = new System.Windows.Forms.Panel();
            this.playPauseButton = new System.Windows.Forms.Button();
            this.timeLabel = new System.Windows.Forms.Label();
            this.btn_creat_key = new System.Windows.Forms.Button();
            this.btn_restart = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.檔案ToolStripMenuItem,
            this.編輯ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1924, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 檔案ToolStripMenuItem
            // 
            this.檔案ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LoadAudioMenuItem,
            this.LoadFile_ToolStripMenuItem,
            this.Export_ToolStripMenuItem,
            this.SaveToolStripMenuItem});
            this.檔案ToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.檔案ToolStripMenuItem.Name = "檔案ToolStripMenuItem";
            this.檔案ToolStripMenuItem.Size = new System.Drawing.Size(53, 23);
            this.檔案ToolStripMenuItem.Text = "檔案";
            // 
            // LoadAudioMenuItem
            // 
            this.LoadAudioMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LoadAudioMenuItem.Name = "LoadAudioMenuItem";
            this.LoadAudioMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.M)));
            this.LoadAudioMenuItem.Size = new System.Drawing.Size(213, 26);
            this.LoadAudioMenuItem.Text = "載入音樂";
            this.LoadAudioMenuItem.Click += new System.EventHandler(this.LoadAudioMenuItem_Click);
            // 
            // LoadFile_ToolStripMenuItem
            // 
            this.LoadFile_ToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LoadFile_ToolStripMenuItem.Name = "LoadFile_ToolStripMenuItem";
            this.LoadFile_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.LoadFile_ToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.LoadFile_ToolStripMenuItem.Text = "開啟舊檔";
            this.LoadFile_ToolStripMenuItem.Click += new System.EventHandler(this.LoadFile_ToolStripMenuItem_Click);
            // 
            // Export_ToolStripMenuItem
            // 
            this.Export_ToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Export_ToolStripMenuItem.Name = "Export_ToolStripMenuItem";
            this.Export_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.Export_ToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.Export_ToolStripMenuItem.Text = "另存新檔";
            this.Export_ToolStripMenuItem.Click += new System.EventHandler(this.Export_ToolStripMenuItem_Click);
            // 
            // SaveToolStripMenuItem
            // 
            this.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem";
            this.SaveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.SaveToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.SaveToolStripMenuItem.Text = "儲存";
            this.SaveToolStripMenuItem.Click += new System.EventHandler(this.Save_ToolStripMenuItem_Click);
            // 
            // 編輯ToolStripMenuItem
            // 
            this.編輯ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CopyKeyToolStripMenuItem,
            this.PasteKeyToolStripMenuItem,
            this.CutKeyToolStripMenuItem,
            this.DeleteKeyToolStripMenuItem});
            this.編輯ToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.編輯ToolStripMenuItem.Name = "編輯ToolStripMenuItem";
            this.編輯ToolStripMenuItem.Size = new System.Drawing.Size(53, 23);
            this.編輯ToolStripMenuItem.Text = "編輯";
            // 
            // CopyKeyToolStripMenuItem
            // 
            this.CopyKeyToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.CopyKeyToolStripMenuItem.Name = "CopyKeyToolStripMenuItem";
            this.CopyKeyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.CopyKeyToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.CopyKeyToolStripMenuItem.Text = "複製key";
            this.CopyKeyToolStripMenuItem.Click += new System.EventHandler(this.CopyKeyToolStripMenuItem_Click);
            // 
            // PasteKeyToolStripMenuItem
            // 
            this.PasteKeyToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.PasteKeyToolStripMenuItem.Name = "PasteKeyToolStripMenuItem";
            this.PasteKeyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.PasteKeyToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.PasteKeyToolStripMenuItem.Text = "貼上key";
            this.PasteKeyToolStripMenuItem.Click += new System.EventHandler(this.PasteKeyToolStripMenuItem_Click);
            // 
            // CutKeyToolStripMenuItem
            // 
            this.CutKeyToolStripMenuItem.Name = "CutKeyToolStripMenuItem";
            this.CutKeyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.CutKeyToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.CutKeyToolStripMenuItem.Text = "剪下key";
            this.CutKeyToolStripMenuItem.Click += new System.EventHandler(this.CutKeyToolStripMenuItem_Click);
            // 
            // DeleteKeyToolStripMenuItem
            // 
            this.DeleteKeyToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.DeleteKeyToolStripMenuItem.Name = "DeleteKeyToolStripMenuItem";
            this.DeleteKeyToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.DeleteKeyToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.DeleteKeyToolStripMenuItem.Text = "刪除key";
            this.DeleteKeyToolStripMenuItem.Click += new System.EventHandler(this.DeleteKeyToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_color);
            this.panel1.Controls.Add(this.lab_color);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel1.Location = new System.Drawing.Point(0, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1768, 459);
            this.panel1.TabIndex = 2;
            // 
            // btn_color
            // 
            this.btn_color.Location = new System.Drawing.Point(1608, 142);
            this.btn_color.Name = "btn_color";
            this.btn_color.Size = new System.Drawing.Size(78, 70);
            this.btn_color.TabIndex = 7;
            this.btn_color.UseVisualStyleBackColor = true;
            this.btn_color.Click += new System.EventHandler(this.btn_color_Click);
            // 
            // lab_color
            // 
            this.lab_color.AutoSize = true;
            this.lab_color.Location = new System.Drawing.Point(1620, 243);
            this.lab_color.Name = "lab_color";
            this.lab_color.Size = new System.Drawing.Size(17, 19);
            this.lab_color.TabIndex = 6;
            this.lab_color.Text = "  ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txt_p4);
            this.groupBox3.Controls.Add(this.lab_p4);
            this.groupBox3.Controls.Add(this.txt_p3);
            this.groupBox3.Controls.Add(this.lab_p3);
            this.groupBox3.Controls.Add(this.txt_p2);
            this.groupBox3.Controls.Add(this.lab_p2);
            this.groupBox3.Controls.Add(this.txt_p1);
            this.groupBox3.Controls.Add(this.lab_p1);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.comboBox_Mode);
            this.groupBox3.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox3.Location = new System.Drawing.Point(419, 17);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(354, 440);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mode Setting";
            // 
            // txt_p4
            // 
            this.txt_p4.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_p4.Location = new System.Drawing.Point(115, 268);
            this.txt_p4.Name = "txt_p4";
            this.txt_p4.Size = new System.Drawing.Size(100, 27);
            this.txt_p4.TabIndex = 29;
            this.txt_p4.Text = "0";
            // 
            // lab_p4
            // 
            this.lab_p4.AutoSize = true;
            this.lab_p4.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_p4.Location = new System.Drawing.Point(23, 271);
            this.lab_p4.Name = "lab_p4";
            this.lab_p4.Size = new System.Drawing.Size(28, 19);
            this.lab_p4.TabIndex = 28;
            this.lab_p4.Text = "p4";
            // 
            // txt_p3
            // 
            this.txt_p3.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_p3.Location = new System.Drawing.Point(115, 218);
            this.txt_p3.Name = "txt_p3";
            this.txt_p3.Size = new System.Drawing.Size(100, 27);
            this.txt_p3.TabIndex = 27;
            this.txt_p3.Text = "0";
            // 
            // lab_p3
            // 
            this.lab_p3.AutoSize = true;
            this.lab_p3.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_p3.Location = new System.Drawing.Point(23, 221);
            this.lab_p3.Name = "lab_p3";
            this.lab_p3.Size = new System.Drawing.Size(28, 19);
            this.lab_p3.TabIndex = 26;
            this.lab_p3.Text = "p3";
            // 
            // txt_p2
            // 
            this.txt_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_p2.Location = new System.Drawing.Point(115, 173);
            this.txt_p2.Name = "txt_p2";
            this.txt_p2.Size = new System.Drawing.Size(100, 27);
            this.txt_p2.TabIndex = 25;
            this.txt_p2.Text = "0";
            // 
            // lab_p2
            // 
            this.lab_p2.AutoSize = true;
            this.lab_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_p2.Location = new System.Drawing.Point(23, 176);
            this.lab_p2.Name = "lab_p2";
            this.lab_p2.Size = new System.Drawing.Size(28, 19);
            this.lab_p2.TabIndex = 24;
            this.lab_p2.Text = "p2";
            // 
            // txt_p1
            // 
            this.txt_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_p1.Location = new System.Drawing.Point(115, 130);
            this.txt_p1.Name = "txt_p1";
            this.txt_p1.Size = new System.Drawing.Size(100, 27);
            this.txt_p1.TabIndex = 23;
            this.txt_p1.Text = "0";
            // 
            // lab_p1
            // 
            this.lab_p1.AutoSize = true;
            this.lab_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_p1.Location = new System.Drawing.Point(23, 133);
            this.lab_p1.Name = "lab_p1";
            this.lab_p1.Size = new System.Drawing.Size(28, 19);
            this.lab_p1.TabIndex = 22;
            this.lab_p1.Text = "p1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(23, 82);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 19);
            this.label6.TabIndex = 20;
            this.label6.Text = "Mode";
            // 
            // comboBox_Mode
            // 
            this.comboBox_Mode.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_Mode.FormattingEnabled = true;
            this.comboBox_Mode.Items.AddRange(new object[] {
            "CLEAR",
            "PLAIN",
            "SQUARE",
            "SICKLE",
            "FAN",
            "BOXES",
            "MAP_ES",
            "MAP_ES_ZH",
            "CMAP_DNA",
            "CMAP_FIRE",
            "CMAP_BENSON",
            "CMAP_YEN",
            "CMAP_LOVE",
            "CMAP_GEAR",
            "MAP_ESXOPT"});
            this.comboBox_Mode.Location = new System.Drawing.Point(115, 79);
            this.comboBox_Mode.Name = "comboBox_Mode";
            this.comboBox_Mode.Size = new System.Drawing.Size(121, 27);
            this.comboBox_Mode.TabIndex = 0;
            this.comboBox_Mode.Text = "CLEAR";
            this.comboBox_Mode.SelectedIndexChanged += new System.EventHandler(this.comboBox_Mode_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lab_YV_p2);
            this.groupBox2.Controls.Add(this.txt_YV_p2);
            this.groupBox2.Controls.Add(this.lab_YV_p1);
            this.groupBox2.Controls.Add(this.txt_YV_p1);
            this.groupBox2.Controls.Add(this.lab_YV_Lower);
            this.groupBox2.Controls.Add(this.txt_YV_Lower);
            this.groupBox2.Controls.Add(this.lab_YV_Range);
            this.groupBox2.Controls.Add(this.comboBox_YV_func);
            this.groupBox2.Controls.Add(this.txt_YV_Range);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.lab_YS_p2);
            this.groupBox2.Controls.Add(this.txt_YS_p2);
            this.groupBox2.Controls.Add(this.lab_YS_p1);
            this.groupBox2.Controls.Add(this.txt_YS_p1);
            this.groupBox2.Controls.Add(this.lab_YS_Lower);
            this.groupBox2.Controls.Add(this.txt_YS_Lower);
            this.groupBox2.Controls.Add(this.lab_YS_Range);
            this.groupBox2.Controls.Add(this.comboBox_YS_func);
            this.groupBox2.Controls.Add(this.txt_YS_Range);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.lab_YH_p2);
            this.groupBox2.Controls.Add(this.txt_YH_p2);
            this.groupBox2.Controls.Add(this.lab_YH_p1);
            this.groupBox2.Controls.Add(this.txt_YH_p1);
            this.groupBox2.Controls.Add(this.lab_YH_Lower);
            this.groupBox2.Controls.Add(this.txt_YH_Lower);
            this.groupBox2.Controls.Add(this.lab_YH_Range);
            this.groupBox2.Controls.Add(this.comboBox_YH_func);
            this.groupBox2.Controls.Add(this.txt_YH_Range);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.lab_XV_p2);
            this.groupBox2.Controls.Add(this.txt_XV_p2);
            this.groupBox2.Controls.Add(this.lab_XV_p1);
            this.groupBox2.Controls.Add(this.txt_XV_p1);
            this.groupBox2.Controls.Add(this.lab_XV_Lower);
            this.groupBox2.Controls.Add(this.txt_XV_Lower);
            this.groupBox2.Controls.Add(this.lab_XV_Range);
            this.groupBox2.Controls.Add(this.comboBox_XV_func);
            this.groupBox2.Controls.Add(this.txt_XV_Range);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.lab_XS_p2);
            this.groupBox2.Controls.Add(this.txt_XS_p2);
            this.groupBox2.Controls.Add(this.lab_XS_p1);
            this.groupBox2.Controls.Add(this.txt_XS_p1);
            this.groupBox2.Controls.Add(this.lab_XS_Lower);
            this.groupBox2.Controls.Add(this.txt_XS_Lower);
            this.groupBox2.Controls.Add(this.lab_XS_Range);
            this.groupBox2.Controls.Add(this.comboBox_XS_func);
            this.groupBox2.Controls.Add(this.txt_XS_Range);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.lab_XH_p2);
            this.groupBox2.Controls.Add(this.txt_XH_p2);
            this.groupBox2.Controls.Add(this.lab_XH_p1);
            this.groupBox2.Controls.Add(this.txt_XH_p1);
            this.groupBox2.Controls.Add(this.lab_XH_Lower);
            this.groupBox2.Controls.Add(this.txt_XH_Lower);
            this.groupBox2.Controls.Add(this.lab_XH_Range);
            this.groupBox2.Controls.Add(this.comboBox_XH_func);
            this.groupBox2.Controls.Add(this.txt_XH_Range);
            this.groupBox2.Controls.Add(this.lab_XH);
            this.groupBox2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.Location = new System.Drawing.Point(785, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(783, 440);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "HSV Setting";
            // 
            // lab_YV_p2
            // 
            this.lab_YV_p2.AutoSize = true;
            this.lab_YV_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YV_p2.Location = new System.Drawing.Point(616, 361);
            this.lab_YV_p2.Name = "lab_YV_p2";
            this.lab_YV_p2.Size = new System.Drawing.Size(28, 19);
            this.lab_YV_p2.TabIndex = 59;
            this.lab_YV_p2.Text = "p2";
            // 
            // txt_YV_p2
            // 
            this.txt_YV_p2.AcceptsReturn = true;
            this.txt_YV_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YV_p2.Location = new System.Drawing.Point(717, 358);
            this.txt_YV_p2.Name = "txt_YV_p2";
            this.txt_YV_p2.Size = new System.Drawing.Size(43, 27);
            this.txt_YV_p2.TabIndex = 58;
            this.txt_YV_p2.Text = "0";
            // 
            // lab_YV_p1
            // 
            this.lab_YV_p1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_YV_p1.AutoSize = true;
            this.lab_YV_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YV_p1.Location = new System.Drawing.Point(434, 360);
            this.lab_YV_p1.Name = "lab_YV_p1";
            this.lab_YV_p1.Size = new System.Drawing.Size(28, 19);
            this.lab_YV_p1.TabIndex = 57;
            this.lab_YV_p1.Text = "p1";
            // 
            // txt_YV_p1
            // 
            this.txt_YV_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YV_p1.Location = new System.Drawing.Point(527, 357);
            this.txt_YV_p1.Name = "txt_YV_p1";
            this.txt_YV_p1.Size = new System.Drawing.Size(43, 27);
            this.txt_YV_p1.TabIndex = 56;
            this.txt_YV_p1.Text = "0";
            // 
            // lab_YV_Lower
            // 
            this.lab_YV_Lower.AutoSize = true;
            this.lab_YV_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YV_Lower.Location = new System.Drawing.Point(292, 360);
            this.lab_YV_Lower.Name = "lab_YV_Lower";
            this.lab_YV_Lower.Size = new System.Drawing.Size(54, 19);
            this.lab_YV_Lower.TabIndex = 55;
            this.lab_YV_Lower.Text = "Lower";
            // 
            // txt_YV_Lower
            // 
            this.txt_YV_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YV_Lower.Location = new System.Drawing.Point(352, 357);
            this.txt_YV_Lower.Name = "txt_YV_Lower";
            this.txt_YV_Lower.Size = new System.Drawing.Size(43, 27);
            this.txt_YV_Lower.TabIndex = 54;
            this.txt_YV_Lower.Text = "0";
            // 
            // lab_YV_Range
            // 
            this.lab_YV_Range.AutoSize = true;
            this.lab_YV_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YV_Range.Location = new System.Drawing.Point(179, 357);
            this.lab_YV_Range.Name = "lab_YV_Range";
            this.lab_YV_Range.Size = new System.Drawing.Size(55, 19);
            this.lab_YV_Range.TabIndex = 53;
            this.lab_YV_Range.Text = "Range";
            // 
            // comboBox_YV_func
            // 
            this.comboBox_YV_func.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_YV_func.FormattingEnabled = true;
            this.comboBox_YV_func.Items.AddRange(new object[] {
            "None",
            "Const",
            "Ramp",
            "Tri",
            "Pulse",
            "Step"});
            this.comboBox_YV_func.Location = new System.Drawing.Point(82, 357);
            this.comboBox_YV_func.Name = "comboBox_YV_func";
            this.comboBox_YV_func.Size = new System.Drawing.Size(76, 27);
            this.comboBox_YV_func.TabIndex = 52;
            this.comboBox_YV_func.Text = "None";
            this.comboBox_YV_func.SelectedIndexChanged += new System.EventHandler(this.comboBox_YV_func_SelectedIndexChanged);
            // 
            // txt_YV_Range
            // 
            this.txt_YV_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YV_Range.Location = new System.Drawing.Point(240, 357);
            this.txt_YV_Range.Name = "txt_YV_Range";
            this.txt_YV_Range.Size = new System.Drawing.Size(43, 27);
            this.txt_YV_Range.TabIndex = 51;
            this.txt_YV_Range.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label19.Location = new System.Drawing.Point(19, 360);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(28, 19);
            this.label19.TabIndex = 50;
            this.label19.Text = "YV";
            // 
            // lab_YS_p2
            // 
            this.lab_YS_p2.AutoSize = true;
            this.lab_YS_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YS_p2.Location = new System.Drawing.Point(616, 307);
            this.lab_YS_p2.Name = "lab_YS_p2";
            this.lab_YS_p2.Size = new System.Drawing.Size(28, 19);
            this.lab_YS_p2.TabIndex = 49;
            this.lab_YS_p2.Text = "p2";
            // 
            // txt_YS_p2
            // 
            this.txt_YS_p2.AcceptsReturn = true;
            this.txt_YS_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YS_p2.Location = new System.Drawing.Point(717, 304);
            this.txt_YS_p2.Name = "txt_YS_p2";
            this.txt_YS_p2.Size = new System.Drawing.Size(43, 27);
            this.txt_YS_p2.TabIndex = 48;
            this.txt_YS_p2.Text = "0";
            // 
            // lab_YS_p1
            // 
            this.lab_YS_p1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_YS_p1.AutoSize = true;
            this.lab_YS_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YS_p1.Location = new System.Drawing.Point(434, 306);
            this.lab_YS_p1.Name = "lab_YS_p1";
            this.lab_YS_p1.Size = new System.Drawing.Size(28, 19);
            this.lab_YS_p1.TabIndex = 47;
            this.lab_YS_p1.Text = "p1";
            // 
            // txt_YS_p1
            // 
            this.txt_YS_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YS_p1.Location = new System.Drawing.Point(527, 303);
            this.txt_YS_p1.Name = "txt_YS_p1";
            this.txt_YS_p1.Size = new System.Drawing.Size(43, 27);
            this.txt_YS_p1.TabIndex = 46;
            this.txt_YS_p1.Text = "0";
            // 
            // lab_YS_Lower
            // 
            this.lab_YS_Lower.AutoSize = true;
            this.lab_YS_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YS_Lower.Location = new System.Drawing.Point(292, 306);
            this.lab_YS_Lower.Name = "lab_YS_Lower";
            this.lab_YS_Lower.Size = new System.Drawing.Size(54, 19);
            this.lab_YS_Lower.TabIndex = 45;
            this.lab_YS_Lower.Text = "Lower";
            // 
            // txt_YS_Lower
            // 
            this.txt_YS_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YS_Lower.Location = new System.Drawing.Point(352, 303);
            this.txt_YS_Lower.Name = "txt_YS_Lower";
            this.txt_YS_Lower.Size = new System.Drawing.Size(43, 27);
            this.txt_YS_Lower.TabIndex = 44;
            this.txt_YS_Lower.Text = "0";
            // 
            // lab_YS_Range
            // 
            this.lab_YS_Range.AutoSize = true;
            this.lab_YS_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YS_Range.Location = new System.Drawing.Point(179, 303);
            this.lab_YS_Range.Name = "lab_YS_Range";
            this.lab_YS_Range.Size = new System.Drawing.Size(55, 19);
            this.lab_YS_Range.TabIndex = 43;
            this.lab_YS_Range.Text = "Range";
            // 
            // comboBox_YS_func
            // 
            this.comboBox_YS_func.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_YS_func.FormattingEnabled = true;
            this.comboBox_YS_func.Items.AddRange(new object[] {
            "None",
            "Const",
            "Ramp",
            "Tri",
            "Pulse",
            "Step"});
            this.comboBox_YS_func.Location = new System.Drawing.Point(82, 303);
            this.comboBox_YS_func.Name = "comboBox_YS_func";
            this.comboBox_YS_func.Size = new System.Drawing.Size(76, 27);
            this.comboBox_YS_func.TabIndex = 42;
            this.comboBox_YS_func.Text = "None";
            this.comboBox_YS_func.SelectedIndexChanged += new System.EventHandler(this.comboBox_YS_func_SelectedIndexChanged);
            // 
            // txt_YS_Range
            // 
            this.txt_YS_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YS_Range.Location = new System.Drawing.Point(240, 303);
            this.txt_YS_Range.Name = "txt_YS_Range";
            this.txt_YS_Range.Size = new System.Drawing.Size(43, 27);
            this.txt_YS_Range.TabIndex = 41;
            this.txt_YS_Range.Text = "0";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label24.Location = new System.Drawing.Point(19, 306);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(27, 19);
            this.label24.TabIndex = 40;
            this.label24.Text = "YS";
            // 
            // lab_YH_p2
            // 
            this.lab_YH_p2.AutoSize = true;
            this.lab_YH_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YH_p2.Location = new System.Drawing.Point(616, 253);
            this.lab_YH_p2.Name = "lab_YH_p2";
            this.lab_YH_p2.Size = new System.Drawing.Size(28, 19);
            this.lab_YH_p2.TabIndex = 39;
            this.lab_YH_p2.Text = "p2";
            // 
            // txt_YH_p2
            // 
            this.txt_YH_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YH_p2.Location = new System.Drawing.Point(717, 250);
            this.txt_YH_p2.Name = "txt_YH_p2";
            this.txt_YH_p2.Size = new System.Drawing.Size(43, 27);
            this.txt_YH_p2.TabIndex = 38;
            this.txt_YH_p2.Text = "0";
            // 
            // lab_YH_p1
            // 
            this.lab_YH_p1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_YH_p1.AutoSize = true;
            this.lab_YH_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YH_p1.Location = new System.Drawing.Point(434, 252);
            this.lab_YH_p1.Name = "lab_YH_p1";
            this.lab_YH_p1.Size = new System.Drawing.Size(28, 19);
            this.lab_YH_p1.TabIndex = 37;
            this.lab_YH_p1.Text = "p1";
            // 
            // txt_YH_p1
            // 
            this.txt_YH_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YH_p1.Location = new System.Drawing.Point(527, 249);
            this.txt_YH_p1.Name = "txt_YH_p1";
            this.txt_YH_p1.Size = new System.Drawing.Size(43, 27);
            this.txt_YH_p1.TabIndex = 36;
            this.txt_YH_p1.Text = "0";
            // 
            // lab_YH_Lower
            // 
            this.lab_YH_Lower.AutoSize = true;
            this.lab_YH_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YH_Lower.Location = new System.Drawing.Point(292, 252);
            this.lab_YH_Lower.Name = "lab_YH_Lower";
            this.lab_YH_Lower.Size = new System.Drawing.Size(54, 19);
            this.lab_YH_Lower.TabIndex = 35;
            this.lab_YH_Lower.Text = "Lower";
            // 
            // txt_YH_Lower
            // 
            this.txt_YH_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YH_Lower.Location = new System.Drawing.Point(352, 249);
            this.txt_YH_Lower.Name = "txt_YH_Lower";
            this.txt_YH_Lower.Size = new System.Drawing.Size(43, 27);
            this.txt_YH_Lower.TabIndex = 34;
            this.txt_YH_Lower.Text = "0";
            // 
            // lab_YH_Range
            // 
            this.lab_YH_Range.AutoSize = true;
            this.lab_YH_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_YH_Range.Location = new System.Drawing.Point(179, 249);
            this.lab_YH_Range.Name = "lab_YH_Range";
            this.lab_YH_Range.Size = new System.Drawing.Size(55, 19);
            this.lab_YH_Range.TabIndex = 33;
            this.lab_YH_Range.Text = "Range";
            // 
            // comboBox_YH_func
            // 
            this.comboBox_YH_func.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_YH_func.FormattingEnabled = true;
            this.comboBox_YH_func.Items.AddRange(new object[] {
            "None",
            "Const",
            "Ramp",
            "Tri",
            "Pulse",
            "Step"});
            this.comboBox_YH_func.Location = new System.Drawing.Point(82, 249);
            this.comboBox_YH_func.Name = "comboBox_YH_func";
            this.comboBox_YH_func.Size = new System.Drawing.Size(76, 27);
            this.comboBox_YH_func.TabIndex = 32;
            this.comboBox_YH_func.Text = "None";
            this.comboBox_YH_func.SelectedIndexChanged += new System.EventHandler(this.comboBox_YH_func_SelectedIndexChanged);
            // 
            // txt_YH_Range
            // 
            this.txt_YH_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_YH_Range.Location = new System.Drawing.Point(240, 249);
            this.txt_YH_Range.Name = "txt_YH_Range";
            this.txt_YH_Range.Size = new System.Drawing.Size(43, 27);
            this.txt_YH_Range.TabIndex = 31;
            this.txt_YH_Range.Text = "0";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label29.Location = new System.Drawing.Point(19, 252);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(30, 19);
            this.label29.TabIndex = 30;
            this.label29.Text = "YH";
            // 
            // lab_XV_p2
            // 
            this.lab_XV_p2.AutoSize = true;
            this.lab_XV_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XV_p2.Location = new System.Drawing.Point(616, 184);
            this.lab_XV_p2.Name = "lab_XV_p2";
            this.lab_XV_p2.Size = new System.Drawing.Size(28, 19);
            this.lab_XV_p2.TabIndex = 29;
            this.lab_XV_p2.Text = "p2";
            // 
            // txt_XV_p2
            // 
            this.txt_XV_p2.AcceptsReturn = true;
            this.txt_XV_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XV_p2.Location = new System.Drawing.Point(717, 181);
            this.txt_XV_p2.Name = "txt_XV_p2";
            this.txt_XV_p2.Size = new System.Drawing.Size(43, 27);
            this.txt_XV_p2.TabIndex = 28;
            this.txt_XV_p2.Text = "0";
            // 
            // lab_XV_p1
            // 
            this.lab_XV_p1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_XV_p1.AutoSize = true;
            this.lab_XV_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XV_p1.Location = new System.Drawing.Point(434, 183);
            this.lab_XV_p1.Name = "lab_XV_p1";
            this.lab_XV_p1.Size = new System.Drawing.Size(28, 19);
            this.lab_XV_p1.TabIndex = 27;
            this.lab_XV_p1.Text = "p1";
            // 
            // txt_XV_p1
            // 
            this.txt_XV_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XV_p1.Location = new System.Drawing.Point(491, 180);
            this.txt_XV_p1.Name = "txt_XV_p1";
            this.txt_XV_p1.Size = new System.Drawing.Size(79, 27);
            this.txt_XV_p1.TabIndex = 26;
            this.txt_XV_p1.Text = "0";
            // 
            // lab_XV_Lower
            // 
            this.lab_XV_Lower.AutoSize = true;
            this.lab_XV_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XV_Lower.Location = new System.Drawing.Point(292, 183);
            this.lab_XV_Lower.Name = "lab_XV_Lower";
            this.lab_XV_Lower.Size = new System.Drawing.Size(54, 19);
            this.lab_XV_Lower.TabIndex = 25;
            this.lab_XV_Lower.Text = "Lower";
            // 
            // txt_XV_Lower
            // 
            this.txt_XV_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XV_Lower.Location = new System.Drawing.Point(352, 180);
            this.txt_XV_Lower.Name = "txt_XV_Lower";
            this.txt_XV_Lower.Size = new System.Drawing.Size(43, 27);
            this.txt_XV_Lower.TabIndex = 24;
            this.txt_XV_Lower.Text = "0";
            // 
            // lab_XV_Range
            // 
            this.lab_XV_Range.AutoSize = true;
            this.lab_XV_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XV_Range.Location = new System.Drawing.Point(179, 180);
            this.lab_XV_Range.Name = "lab_XV_Range";
            this.lab_XV_Range.Size = new System.Drawing.Size(55, 19);
            this.lab_XV_Range.TabIndex = 23;
            this.lab_XV_Range.Text = "Range";
            // 
            // comboBox_XV_func
            // 
            this.comboBox_XV_func.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_XV_func.FormattingEnabled = true;
            this.comboBox_XV_func.Items.AddRange(new object[] {
            "None",
            "Const",
            "Ramp",
            "Tri",
            "Pulse",
            "Step"});
            this.comboBox_XV_func.Location = new System.Drawing.Point(82, 180);
            this.comboBox_XV_func.Name = "comboBox_XV_func";
            this.comboBox_XV_func.Size = new System.Drawing.Size(76, 27);
            this.comboBox_XV_func.TabIndex = 22;
            this.comboBox_XV_func.Text = "None";
            this.comboBox_XV_func.SelectedIndexChanged += new System.EventHandler(this.comboBox_XV_func_SelectedIndexChanged);
            // 
            // txt_XV_Range
            // 
            this.txt_XV_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XV_Range.Location = new System.Drawing.Point(240, 180);
            this.txt_XV_Range.Name = "txt_XV_Range";
            this.txt_XV_Range.Size = new System.Drawing.Size(43, 27);
            this.txt_XV_Range.TabIndex = 21;
            this.txt_XV_Range.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(19, 183);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 19);
            this.label14.TabIndex = 20;
            this.label14.Text = "XV";
            // 
            // lab_XS_p2
            // 
            this.lab_XS_p2.AutoSize = true;
            this.lab_XS_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XS_p2.Location = new System.Drawing.Point(616, 129);
            this.lab_XS_p2.Name = "lab_XS_p2";
            this.lab_XS_p2.Size = new System.Drawing.Size(28, 19);
            this.lab_XS_p2.TabIndex = 19;
            this.lab_XS_p2.Text = "p2";
            // 
            // txt_XS_p2
            // 
            this.txt_XS_p2.AcceptsReturn = true;
            this.txt_XS_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XS_p2.Location = new System.Drawing.Point(717, 126);
            this.txt_XS_p2.Name = "txt_XS_p2";
            this.txt_XS_p2.Size = new System.Drawing.Size(43, 27);
            this.txt_XS_p2.TabIndex = 18;
            this.txt_XS_p2.Text = "0";
            // 
            // lab_XS_p1
            // 
            this.lab_XS_p1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_XS_p1.AutoSize = true;
            this.lab_XS_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XS_p1.Location = new System.Drawing.Point(434, 128);
            this.lab_XS_p1.Name = "lab_XS_p1";
            this.lab_XS_p1.Size = new System.Drawing.Size(28, 19);
            this.lab_XS_p1.TabIndex = 17;
            this.lab_XS_p1.Text = "p1";
            // 
            // txt_XS_p1
            // 
            this.txt_XS_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XS_p1.Location = new System.Drawing.Point(491, 125);
            this.txt_XS_p1.Name = "txt_XS_p1";
            this.txt_XS_p1.Size = new System.Drawing.Size(79, 27);
            this.txt_XS_p1.TabIndex = 16;
            this.txt_XS_p1.Text = "0";
            // 
            // lab_XS_Lower
            // 
            this.lab_XS_Lower.AutoSize = true;
            this.lab_XS_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XS_Lower.Location = new System.Drawing.Point(292, 128);
            this.lab_XS_Lower.Name = "lab_XS_Lower";
            this.lab_XS_Lower.Size = new System.Drawing.Size(54, 19);
            this.lab_XS_Lower.TabIndex = 15;
            this.lab_XS_Lower.Text = "Lower";
            // 
            // txt_XS_Lower
            // 
            this.txt_XS_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XS_Lower.Location = new System.Drawing.Point(352, 125);
            this.txt_XS_Lower.Name = "txt_XS_Lower";
            this.txt_XS_Lower.Size = new System.Drawing.Size(43, 27);
            this.txt_XS_Lower.TabIndex = 14;
            this.txt_XS_Lower.Text = "0";
            // 
            // lab_XS_Range
            // 
            this.lab_XS_Range.AutoSize = true;
            this.lab_XS_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XS_Range.Location = new System.Drawing.Point(179, 125);
            this.lab_XS_Range.Name = "lab_XS_Range";
            this.lab_XS_Range.Size = new System.Drawing.Size(55, 19);
            this.lab_XS_Range.TabIndex = 13;
            this.lab_XS_Range.Text = "Range";
            // 
            // comboBox_XS_func
            // 
            this.comboBox_XS_func.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_XS_func.FormattingEnabled = true;
            this.comboBox_XS_func.Items.AddRange(new object[] {
            "None",
            "Const",
            "Ramp",
            "Tri",
            "Pulse",
            "Step"});
            this.comboBox_XS_func.Location = new System.Drawing.Point(82, 125);
            this.comboBox_XS_func.Name = "comboBox_XS_func";
            this.comboBox_XS_func.Size = new System.Drawing.Size(76, 27);
            this.comboBox_XS_func.TabIndex = 12;
            this.comboBox_XS_func.Text = "None";
            this.comboBox_XS_func.SelectedIndexChanged += new System.EventHandler(this.comboBox_XS_func_SelectedIndexChanged);
            // 
            // txt_XS_Range
            // 
            this.txt_XS_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XS_Range.Location = new System.Drawing.Point(240, 125);
            this.txt_XS_Range.Name = "txt_XS_Range";
            this.txt_XS_Range.Size = new System.Drawing.Size(43, 27);
            this.txt_XS_Range.TabIndex = 11;
            this.txt_XS_Range.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(19, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 19);
            this.label5.TabIndex = 10;
            this.label5.Text = "XS";
            // 
            // lab_XH_p2
            // 
            this.lab_XH_p2.AutoSize = true;
            this.lab_XH_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XH_p2.Location = new System.Drawing.Point(616, 77);
            this.lab_XH_p2.Name = "lab_XH_p2";
            this.lab_XH_p2.Size = new System.Drawing.Size(28, 19);
            this.lab_XH_p2.TabIndex = 9;
            this.lab_XH_p2.Text = "p2";
            // 
            // txt_XH_p2
            // 
            this.txt_XH_p2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XH_p2.Location = new System.Drawing.Point(717, 74);
            this.txt_XH_p2.Name = "txt_XH_p2";
            this.txt_XH_p2.Size = new System.Drawing.Size(43, 27);
            this.txt_XH_p2.TabIndex = 8;
            this.txt_XH_p2.Text = "0";
            // 
            // lab_XH_p1
            // 
            this.lab_XH_p1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_XH_p1.AutoSize = true;
            this.lab_XH_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XH_p1.Location = new System.Drawing.Point(434, 76);
            this.lab_XH_p1.Name = "lab_XH_p1";
            this.lab_XH_p1.Size = new System.Drawing.Size(28, 19);
            this.lab_XH_p1.TabIndex = 7;
            this.lab_XH_p1.Text = "p1";
            // 
            // txt_XH_p1
            // 
            this.txt_XH_p1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XH_p1.Location = new System.Drawing.Point(491, 73);
            this.txt_XH_p1.Name = "txt_XH_p1";
            this.txt_XH_p1.Size = new System.Drawing.Size(79, 27);
            this.txt_XH_p1.TabIndex = 6;
            this.txt_XH_p1.Text = "0";
            // 
            // lab_XH_Lower
            // 
            this.lab_XH_Lower.AutoSize = true;
            this.lab_XH_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XH_Lower.Location = new System.Drawing.Point(292, 76);
            this.lab_XH_Lower.Name = "lab_XH_Lower";
            this.lab_XH_Lower.Size = new System.Drawing.Size(54, 19);
            this.lab_XH_Lower.TabIndex = 5;
            this.lab_XH_Lower.Text = "Lower";
            // 
            // txt_XH_Lower
            // 
            this.txt_XH_Lower.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XH_Lower.Location = new System.Drawing.Point(352, 73);
            this.txt_XH_Lower.Name = "txt_XH_Lower";
            this.txt_XH_Lower.Size = new System.Drawing.Size(43, 27);
            this.txt_XH_Lower.TabIndex = 4;
            this.txt_XH_Lower.Text = "0";
            // 
            // lab_XH_Range
            // 
            this.lab_XH_Range.AutoSize = true;
            this.lab_XH_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XH_Range.Location = new System.Drawing.Point(179, 73);
            this.lab_XH_Range.Name = "lab_XH_Range";
            this.lab_XH_Range.Size = new System.Drawing.Size(55, 19);
            this.lab_XH_Range.TabIndex = 3;
            this.lab_XH_Range.Text = "Range";
            // 
            // comboBox_XH_func
            // 
            this.comboBox_XH_func.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_XH_func.FormattingEnabled = true;
            this.comboBox_XH_func.Items.AddRange(new object[] {
            "None",
            "Const",
            "Ramp",
            "Tri",
            "Pulse",
            "Step"});
            this.comboBox_XH_func.Location = new System.Drawing.Point(82, 73);
            this.comboBox_XH_func.Name = "comboBox_XH_func";
            this.comboBox_XH_func.Size = new System.Drawing.Size(76, 27);
            this.comboBox_XH_func.TabIndex = 2;
            this.comboBox_XH_func.Text = "None";
            this.comboBox_XH_func.SelectedIndexChanged += new System.EventHandler(this.comboBox_XH_func_SelectedIndexChanged);
            // 
            // txt_XH_Range
            // 
            this.txt_XH_Range.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_XH_Range.Location = new System.Drawing.Point(240, 73);
            this.txt_XH_Range.Name = "txt_XH_Range";
            this.txt_XH_Range.Size = new System.Drawing.Size(43, 27);
            this.txt_XH_Range.TabIndex = 1;
            this.txt_XH_Range.Text = "0";
            // 
            // lab_XH
            // 
            this.lab_XH.AutoSize = true;
            this.lab_XH.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_XH.Location = new System.Drawing.Point(19, 76);
            this.lab_XH.Name = "lab_XH";
            this.lab_XH.Size = new System.Drawing.Size(31, 19);
            this.lab_XH.TabIndex = 0;
            this.lab_XH.Text = "XH";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox_effect);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(12, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 440);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Effect List";
            // 
            // listBox_effect
            // 
            this.listBox_effect.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.listBox_effect.FormattingEnabled = true;
            this.listBox_effect.ItemHeight = 19;
            this.listBox_effect.Location = new System.Drawing.Point(15, 24);
            this.listBox_effect.Name = "listBox_effect";
            this.listBox_effect.Size = new System.Drawing.Size(346, 403);
            this.listBox_effect.TabIndex = 0;
            this.listBox_effect.SelectedIndexChanged += new System.EventHandler(this.ListBox_effect_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel2.Location = new System.Drawing.Point(0, 524);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1582, 496);
            this.panel2.TabIndex = 3;
            // 
            // panelWaveform
            // 
            this.panelWaveform.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panelWaveform.Location = new System.Drawing.Point(39, 535);
            this.panelWaveform.Name = "panelWaveform";
            this.panelWaveform.Size = new System.Drawing.Size(1729, 226);
            this.panelWaveform.TabIndex = 3;
            this.panelWaveform.Paint += new System.Windows.Forms.PaintEventHandler(this.panelWaveform_Paint);
            this.panelWaveform.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelWaveform_MouseClick);
            // 
            // playPauseButton
            // 
            this.playPauseButton.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.playPauseButton.Location = new System.Drawing.Point(72, 498);
            this.playPauseButton.Name = "playPauseButton";
            this.playPauseButton.Size = new System.Drawing.Size(75, 27);
            this.playPauseButton.TabIndex = 4;
            this.playPauseButton.Text = "play/pause";
            this.playPauseButton.UseVisualStyleBackColor = true;
            this.playPauseButton.Click += new System.EventHandler(this.PlayPauseButton_Click);
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.timeLabel.Location = new System.Drawing.Point(153, 504);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(31, 19);
            this.timeLabel.TabIndex = 5;
            this.timeLabel.Text = "0:0";
            // 
            // btn_creat_key
            // 
            this.btn_creat_key.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_creat_key.Location = new System.Drawing.Point(877, 498);
            this.btn_creat_key.Name = "btn_creat_key";
            this.btn_creat_key.Size = new System.Drawing.Size(100, 31);
            this.btn_creat_key.TabIndex = 6;
            this.btn_creat_key.Text = "新增KEY";
            this.btn_creat_key.UseVisualStyleBackColor = true;
            this.btn_creat_key.Click += new System.EventHandler(this.btn_create_key_Click);
            // 
            // btn_restart
            // 
            this.btn_restart.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_restart.Location = new System.Drawing.Point(267, 498);
            this.btn_restart.Name = "btn_restart";
            this.btn_restart.Size = new System.Drawing.Size(75, 26);
            this.btn_restart.TabIndex = 7;
            this.btn_restart.Text = "stop";
            this.btn_restart.UseVisualStyleBackColor = true;
            this.btn_restart.Click += new System.EventHandler(this.btn_restart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1924, 831);
            this.Controls.Add(this.btn_restart);
            this.Controls.Add(this.btn_creat_key);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.playPauseButton);
            this.Controls.Add(this.panelWaveform);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "   ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 檔案ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem LoadAudioMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 編輯ToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem LoadFile_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Export_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CopyKeyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PasteKeyToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panelWaveform;
        private System.Windows.Forms.Button playPauseButton;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Button btn_creat_key;
        private System.Windows.Forms.TextBox txt_XH_Range;
        private System.Windows.Forms.Label lab_XH;
        private System.Windows.Forms.ComboBox comboBox_XH_func;
        private System.Windows.Forms.Label lab_XH_Range;
        private System.Windows.Forms.Label lab_XH_p2;
        private System.Windows.Forms.TextBox txt_XH_p2;
        private System.Windows.Forms.Label lab_XH_p1;
        private System.Windows.Forms.TextBox txt_XH_p1;
        private System.Windows.Forms.Label lab_XH_Lower;
        private System.Windows.Forms.TextBox txt_XH_Lower;
        private System.Windows.Forms.ListBox listBox_effect;
        private System.Windows.Forms.Label lab_XS_p2;
        private System.Windows.Forms.TextBox txt_XS_p2;
        private System.Windows.Forms.Label lab_XS_p1;
        private System.Windows.Forms.TextBox txt_XS_p1;
        private System.Windows.Forms.Label lab_XS_Lower;
        private System.Windows.Forms.TextBox txt_XS_Lower;
        private System.Windows.Forms.Label lab_XS_Range;
        private System.Windows.Forms.ComboBox comboBox_XS_func;
        private System.Windows.Forms.TextBox txt_XS_Range;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_Mode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lab_p1;
        private System.Windows.Forms.TextBox txt_p1;
        private System.Windows.Forms.TextBox txt_p4;
        private System.Windows.Forms.Label lab_p4;
        private System.Windows.Forms.TextBox txt_p3;
        private System.Windows.Forms.Label lab_p3;
        private System.Windows.Forms.TextBox txt_p2;
        private System.Windows.Forms.Label lab_p2;
        private System.Windows.Forms.Label lab_XV_p2;
        private System.Windows.Forms.TextBox txt_XV_p2;
        private System.Windows.Forms.Label lab_XV_p1;
        private System.Windows.Forms.TextBox txt_XV_p1;
        private System.Windows.Forms.Label lab_XV_Lower;
        private System.Windows.Forms.TextBox txt_XV_Lower;
        private System.Windows.Forms.Label lab_XV_Range;
        private System.Windows.Forms.ComboBox comboBox_XV_func;
        private System.Windows.Forms.TextBox txt_XV_Range;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lab_YV_p2;
        private System.Windows.Forms.TextBox txt_YV_p2;
        private System.Windows.Forms.Label lab_YV_p1;
        private System.Windows.Forms.TextBox txt_YV_p1;
        private System.Windows.Forms.Label lab_YV_Lower;
        private System.Windows.Forms.TextBox txt_YV_Lower;
        private System.Windows.Forms.Label lab_YV_Range;
        private System.Windows.Forms.ComboBox comboBox_YV_func;
        private System.Windows.Forms.TextBox txt_YV_Range;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lab_YS_p2;
        private System.Windows.Forms.TextBox txt_YS_p2;
        private System.Windows.Forms.Label lab_YS_p1;
        private System.Windows.Forms.TextBox txt_YS_p1;
        private System.Windows.Forms.Label lab_YS_Lower;
        private System.Windows.Forms.TextBox txt_YS_Lower;
        private System.Windows.Forms.Label lab_YS_Range;
        private System.Windows.Forms.ComboBox comboBox_YS_func;
        private System.Windows.Forms.TextBox txt_YS_Range;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lab_YH_p2;
        private System.Windows.Forms.TextBox txt_YH_p2;
        private System.Windows.Forms.Label lab_YH_p1;
        private System.Windows.Forms.TextBox txt_YH_p1;
        private System.Windows.Forms.Label lab_YH_Lower;
        private System.Windows.Forms.TextBox txt_YH_Lower;
        private System.Windows.Forms.Label lab_YH_Range;
        private System.Windows.Forms.ComboBox comboBox_YH_func;
        private System.Windows.Forms.TextBox txt_YH_Range;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ToolStripMenuItem DeleteKeyToolStripMenuItem;
        private System.Windows.Forms.Button btn_color;
        private System.Windows.Forms.Label lab_color;
        private System.Windows.Forms.ToolStripMenuItem CutKeyToolStripMenuItem;
        private System.Windows.Forms.Button btn_restart;
        private System.Windows.Forms.ToolStripMenuItem SaveToolStripMenuItem;
    }
}

